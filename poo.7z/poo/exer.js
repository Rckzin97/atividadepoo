var entrada = require('readline-sync');
var numeros = [];
var maior = 0;
var menor = 0;
for (var i = 0; i < 15; i++) {
    numeros[i] = parseFloat(entrada.question(''));
}
for (var i = 0; i < 15; i++) {
    if (numeros[i] > maior) {
        maior = numeros[i];
    }
}
if (numeros[1] < menor) {
    menor = numeros[1];
}
console.log(maior);
console.log(menor);
