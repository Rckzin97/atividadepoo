
for(let i=99;i<200;i=i+2){
    console.log(i)
}