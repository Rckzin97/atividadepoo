const entrada4 = require("readline-sync");


for(let i=0; i < 100; i++){

   
   if( i % 2 == 0 || i % 3 == 0 ){

    if(i == 2 || i == 3){console.log(i);}

    else{ let inu = 5;}


   }

   else{

    console.log(i);

   }

}