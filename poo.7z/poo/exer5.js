var entrada5 = require("readline-sync");
var vetor = [];
var d = [];
var i = 0;
for (i; i < 20; i++) {
    vetor[i] = parseFloat(entrada5.question("digite um numero: "));
    if (vetor[i] % 4 == 0) {
        d.push(vetor[i]);
    }
}
console.log(d);
