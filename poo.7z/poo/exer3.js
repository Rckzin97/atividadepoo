var entrada3 = require('readline-sync');
var l = entrada3.question('Digite um numero');
for (var i = l - 1; 1 < i; i--) {
    l = l * i;
}
console.log(l);
