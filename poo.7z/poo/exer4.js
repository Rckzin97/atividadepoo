var entrada4 = require("readline-sync");
for (var i = 0; i < 100; i++) {
    if (i % 2 == 0 || i % 3 == 0) {
        if (i == 2 || i == 3) {
            console.log(i);
        }
        else {
            var inu = 5;
        }
    }
    else {
        console.log(i);
    }
}
